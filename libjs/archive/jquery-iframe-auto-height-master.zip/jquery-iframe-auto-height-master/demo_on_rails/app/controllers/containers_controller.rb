class ContainersController < ApplicationController
  def index
  end

end
