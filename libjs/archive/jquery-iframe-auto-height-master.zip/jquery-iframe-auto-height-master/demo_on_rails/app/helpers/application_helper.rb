module ApplicationHelper
  def header(s)
    return raw "<h2>#{s}</h2>"
  end
end
